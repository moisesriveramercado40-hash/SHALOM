import { User } from '@/types';

// MOCK DATABASE OF USERS
const USERS: User[] = [
    {
        email: 'discipulador@shalom.com',
        role: 'DISCIPULADOR',
        name: 'Pastor Principal',
    },
    {
        email: 'roy@shalom.com',
        role: 'LIDER',
        celulaId: 'cell-1',
        name: 'Roy & Dexi',
    },
    {
        email: 'kevin@shalom.com',
        role: 'LIDER',
        celulaId: 'cell-2',
        name: 'Kevin & Angela',
    },
    {
        email: 'paola@shalom.com',
        role: 'LIDER',
        celulaId: 'cell-3',
        name: 'Paola',
    },
    {
        email: 'wilgrey@shalom.com',
        role: 'LIDER',
        celulaId: 'cell-4',
        name: 'Wilgrey',
    },
    {
        email: 'marizet@shalom.com',
        role: 'LIDER',
        celulaId: 'cell-5',
        name: 'Marizet',
    },
];

export function authenticateUser(email: string): User | null {
    const user = USERS.find((u) => u.email.toLowerCase() === email.toLowerCase());
    return user || null;
}

export function getUser(email: string): User | null {
    return authenticateUser(email);
}

export function getCells() {
    return [
        { id: 'cell-1', name: 'Roy & Dexi', leaderId: 'roy@shalom.com' },
        { id: 'cell-2', name: 'Kevin & Angela', leaderId: 'kevin@shalom.com' },
        { id: 'cell-3', name: 'Paola', leaderId: 'paola@shalom.com' },
        { id: 'cell-4', name: 'Wilgrey', leaderId: 'wilgrey@shalom.com' },
        { id: 'cell-5', name: 'Marizet', leaderId: 'marizet@shalom.com' },
    ];
}
