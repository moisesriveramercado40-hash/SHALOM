"use client";

import { useState } from 'react';
import { useApp } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { FileSpreadsheet, Upload, Download, AlertCircle, CheckCircle } from 'lucide-react';
import { generateMonthlyReport, parseUploadedReport } from '@/lib/excel';

export default function ReportsPage() {
    const { user, members, attendance, cells } = useApp();
    const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle');
    const [statusMessage, setStatusMessage] = useState('');
    const today = new Date();

    if (!user) return null;

    // For Discipulador: Show all cells to download
    // For Leader: Show only their cell
    const availableCells = user.role === 'DISCIPULADOR'
        ? cells
        : cells.filter(c => c.id === user.celulaId);

    const handleDownload = async (cellId: string, cellName: string) => {
        const buffer = await generateMonthlyReport(
            today.getMonth() + 1,
            today.getFullYear(),
            members.filter(m => m.celulaId === cellId),
            attendance.filter(a => a.celulaId === cellId)
        );

        const blob = new Blob([buffer], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        });

        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Reporte_${cellName}_${today.getMonth() + 1}_${today.getFullYear()}.xlsx`;
        a.click();
        URL.revokeObjectURL(url);
    };




    const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        try {
            const buffer = await file.arrayBuffer();
            // @ts-ignore
            const rows = await parseUploadedReport(buffer);

            console.log('DATOS OK:', rows);
            alert('Reporte cargado correctamente');
        } catch (err: any) {
            alert(err.message);
        }
    };


    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-shalom-900">Reportes Mensuales</h1>
                    <p className="text-muted-foreground">Descarga y subida de informes Excel</p>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
                {/* DOWNLOAD SECTION */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Download className="text-shalom-600" />
                            Descargar Plantilla
                        </CardTitle>
                        <CardDescription>
                            Obtenga el formato Excel con los datos actuales para rellenar offline.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {availableCells.map(cell => (
                            <div key={cell.id} className="flex items-center justify-between p-3 border rounded-md">
                                <div className="flex items-center gap-3">
                                    <FileSpreadsheet className="text-green-600" />
                                    <span className="font-medium">{cell.name}</span>
                                </div>
                                <Button variant="outline" size="sm" onClick={() => handleDownload(cell.id, cell.name)}>
                                    Descargar
                                </Button>
                            </div>
                        ))}
                    </CardContent>
                </Card>

                {/* UPLOAD SECTION - ONLY LEADERS */}
                {user.role === 'LIDER' && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Upload className="text-blue-600" />
                                Subir Reporte Mensual
                            </CardTitle>
                            <CardDescription>
                                Suba el Excel completado para actualizar el sistema.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:bg-gray-50 transition-colors cursor-pointer relative">
                                <input
                                    type="file"
                                    accept=".xlsx, .xls"
                                    onChange={handleUpload}
                                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                />
                                <FileSpreadsheet className="mx-auto h-12 w-12 text-gray-400" />
                                <p className="mt-2 text-sm text-gray-600 font-medium">Click para seleccionar archivo</p>
                                <p className="text-xs text-gray-500">Formato .xlsx (Máx 5MB)</p>
                            </div>

                            {uploadStatus === 'success' && (
                                <div className="p-3 bg-green-50 text-green-700 rounded-md flex items-center gap-2 text-sm">
                                    <CheckCircle size={16} />
                                    {statusMessage}
                                </div>
                            )}

                            {uploadStatus === 'error' && (
                                <div className="p-3 bg-red-50 text-red-700 rounded-md flex items-center gap-2 text-sm">
                                    <AlertCircle size={16} />
                                    {statusMessage}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                )}
            </div>

            {user.role === 'DISCIPULADOR' && (
                <Card>
                    <CardHeader>
                        <CardTitle>Historial de Reportes</CardTitle>
                        <CardDescription>Archivos subidos recientemente por los líderes</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="text-sm text-muted-foreground text-center py-8">
                            No hay reportes históricos en esta demo.
                        </p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}
