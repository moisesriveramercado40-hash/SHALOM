"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
    Users,
    LayoutDashboard,
    CalendarCheck,
    FileSpreadsheet,
    LogOut,
    Menu,
    X
} from 'lucide-react';
import { useState } from 'react';
import { useApp } from '@/lib/store';
import { Button } from './ui/button';

export function Sidebar() {
    const pathname = usePathname();
    const [isOpen, setIsOpen] = useState(false);
    const { user, logout } = useApp();

    const links = [
        { href: '/dashboard', label: 'Inicio', icon: LayoutDashboard },
        { href: '/dashboard/miembros', label: 'Miembros', icon: Users },
        { href: '/dashboard/asistencia', label: 'Asistencia', icon: CalendarCheck },
        { href: '/dashboard/reportes', label: 'Reportes Excel', icon: FileSpreadsheet },
    ];

    if (user?.role === 'DISCIPULADOR') {
        links.splice(1, 0, { href: '/dashboard/celulas', label: 'Células', icon: Users });
    }

    const handleLogout = () => {
        logout();
        window.location.href = '/';
    };

    return (
        <>
            {/* Mobile Toggle */}
            <div className="md:hidden p-4 bg-shalom-600 text-white flex justify-between items-center">
                <span className="font-bold text-lg">Shalom App</span>
                <button onClick={() => setIsOpen(!isOpen)}>
                    {isOpen ? <X /> : <Menu />}
                </button>
            </div>

            {/* Sidebar Container */}
            <div className={cn(
                "fixed inset-y-0 left-0 z-50 w-64 bg-shalom-900 text-white transition-transform duration-300 md:relative md:translate-x-0",
                isOpen ? "translate-x-0" : "-translate-x-full"
            )}>
                <div className="p-6">
                    <h1 className="text-2xl font-bold text-shalom-100 mb-2">Shalom</h1>
                    <p className="text-xs text-shalom-300 uppercase tracking-widest mb-8">Discipulado</p>

                    <div className="mb-8 p-3 bg-shalom-800 rounded-lg">
                        <p className="text-sm font-medium">{user?.name}</p>
                        <p className="text-xs text-shalom-300 capitalize">{user?.role.toLowerCase()}</p>
                    </div>

                    <nav className="space-y-2">
                        {links.map((link) => {
                            const Icon = link.icon;
                            const isActive = pathname === link.href;
                            return (
                                <Link
                                    key={link.href}
                                    href={link.href}
                                    onClick={() => setIsOpen(false)}
                                    className={cn(
                                        "flex items-center gap-3 px-4 py-3 rounded-md transition-colors",
                                        isActive
                                            ? "bg-shalom-600 text-white shadow-md"
                                            : "text-shalom-100 hover:bg-shalom-800"
                                    )}
                                >
                                    <Icon size={20} />
                                    <span>{link.label}</span>
                                </Link>
                            );
                        })}
                    </nav>
                </div>

                <div className="absolute bottom-4 left-0 w-full px-6">
                    <Button
                        variant="destructive"
                        className="w-full gap-2 justify-start"
                        onClick={handleLogout}
                    >
                        <LogOut size={18} />
                        <span>Cerrar Sesión</span>
                    </Button>
                </div>
            </div>

            {/* Overlay for mobile */}
            {isOpen && (
                <div
                    className="fixed inset-0 bg-black/50 z-40 md:hidden"
                    onClick={() => setIsOpen(false)}
                />
            )}
        </>
    );
}
