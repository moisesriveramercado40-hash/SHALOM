"use client";

import { useState } from 'react';
import { useApp } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Plus, Search } from 'lucide-react';
import { Member } from '@/types';

export default function ValidMembersPage() {
    const { user, members, addMember, updateMember } = useApp();
    const [searchTerm, setSearchTerm] = useState('');
    const [isAdding, setIsAdding] = useState(false);
    const [isEditing, setIsEditing] = useState<string | null>(null);

    // Form State
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [birthday, setBirthday] = useState('');
    const [memberType, setMemberType] = useState<'MIEMBRO' | 'ASISTENTE' | 'VISITA'>('VISITA');
    const [wentToEncounter, setWentToEncounter] = useState(false);
    const [isBaptized, setIsBaptized] = useState(false);
    const [schoolLevel, setSchoolLevel] = useState('NINGUNO');

    if (!user) return null;

    const myMembers = user.role === 'DISCIPULADOR'
        ? members
        : members.filter(m => m.celulaId === user.celulaId);

    const filteredMembers = myMembers.filter(m =>
        m.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const resetForm = () => {
        setName('');
        setPhone('');
        setBirthday('');
        setMemberType('VISITA');
        setWentToEncounter(false);
        setIsBaptized(false);
        setSchoolLevel('NINGUNO');
        setIsAdding(false);
        setIsEditing(null);
    };

    const handleEditClick = (member: Member) => {
        setName(member.name);
        setPhone(member.phone || '');
        setBirthday(member.birthday || '');
        setMemberType(member.memberType || 'VISITA');
        setWentToEncounter(member.wentToEncounter || false);
        setIsBaptized(member.isBaptized || false);
        setSchoolLevel(member.leadershipSchoolLevel || 'NINGUNO');

        setIsEditing(member.id);
        setIsAdding(true);
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        // Common data
        const memberData = {
            name,
            phone,
            birthday,
            memberType,
            wentToEncounter,
            isBaptized,
            leadershipSchoolLevel: schoolLevel as any, // Cast to match type
        };

        if (isEditing) {
            // Update existing
            const existing = members.find(m => m.id === isEditing);
            if (existing) {
                updateMember({
                    ...existing,
                    ...memberData
                });
            }
        } else {
            // Create new
            if (!user.celulaId && user.role !== 'DISCIPULADOR') return;
            const targetCellId = user.celulaId || 'cell-1';

            const newMember: Member = {
                id: Math.random().toString(36).substr(2, 9),
                celulaId: targetCellId,
                joinDate: new Date().toISOString().split('T')[0],
                active: true,
                ...memberData
            };
            addMember(newMember);
        }
        resetForm();
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-shalom-900">Miembros</h1>
                    <p className="text-muted-foreground">Gestión de discípulos de {user.role === 'DISCIPULADOR' ? 'todas las células' : 'tu célula'}</p>
                </div>
                {!isAdding && (
                    <Button onClick={() => setIsAdding(true)} className="bg-shalom-600 gap-2">
                        <Plus size={16} /> {isEditing ? 'Editar Miembro' : 'Nuevo Miembro'}
                    </Button>
                )}
            </div>

            {isAdding && (
                <Card className="border-shalom-200 bg-shalom-50/50">
                    <CardHeader>
                        <CardTitle>{isEditing ? 'Editar Miembro' : 'Agregar Nuevo Miembro'}</CardTitle>
                        <CardDescription>Actualice los datos del discípulo</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="grid gap-4 md:grid-cols-2">
                                <div className="space-y-2">
                                    <label className="text-sm font-medium">Nombre Completo</label>
                                    <Input required value={name} onChange={e => setName(e.target.value)} placeholder="Ej. Juan Pérez" />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium">Teléfono</label>
                                    <Input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+51 900 000 000" />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium">Cumpleaños</label>
                                    <Input type="date" value={birthday} onChange={e => setBirthday(e.target.value)} />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium">Tipo de Miembro</label>
                                    <select
                                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                        value={memberType}
                                        onChange={e => setMemberType(e.target.value as any)}
                                    >
                                        <option value="VISITA">Visita</option>
                                        <option value="ASISTENTE">Asistente</option>
                                        <option value="MIEMBRO">Miembro</option>
                                    </select>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium">Nivel Escuela</label>
                                    <select
                                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                        value={schoolLevel}
                                        onChange={e => setSchoolLevel(e.target.value)}
                                    >
                                        <option value="NINGUNO">Ninguno</option>
                                        <option value="NIVEL 1">Nivel 1</option>
                                        <option value="NIVEL 2">Nivel 2</option>
                                        <option value="NIVEL 3">Nivel 3</option>
                                        <option value="GRADUADO">Graduado</option>
                                    </select>
                                </div>
                            </div>

                            <div className="flex gap-6 pt-2">
                                <div className="flex items-center space-x-2">
                                    <input
                                        type="checkbox"
                                        id="encounter"
                                        className="h-4 w-4 rounded border-gray-300 text-shalom-600 focus:ring-shalom-600"
                                        checked={wentToEncounter}
                                        onChange={e => setWentToEncounter(e.target.checked)}
                                    />
                                    <label htmlFor="encounter" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                        Fue al Encuentro
                                    </label>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <input
                                        type="checkbox"
                                        id="baptized"
                                        className="h-4 w-4 rounded border-gray-300 text-shalom-600 focus:ring-shalom-600"
                                        checked={isBaptized}
                                        onChange={e => setIsBaptized(e.target.checked)}
                                    />
                                    <label htmlFor="baptized" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                        Bautizado
                                    </label>
                                </div>
                            </div>

                            <div className="flex gap-2 pt-4">
                                <Button type="submit" className="flex-1 bg-shalom-600">{isEditing ? 'Actualizar' : 'Guardar'}</Button>
                                <Button type="button" variant="outline" onClick={resetForm}>Cancelar</Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            )}

            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle>Listado de Miembros</CardTitle>
                        <div className="relative w-64">
                            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input
                                placeholder="Buscar por nombre..."
                                className="pl-8"
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                            />
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="rounded-md border overflow-x-auto">
                        <table className="w-full text-sm text-left">
                            <thead className="bg-muted/50 text-muted-foreground">
                                <tr>
                                    <th className="p-4 font-medium">Nombre</th>
                                    <th className="p-4 font-medium">Tipo</th>
                                    <th className="p-4 font-medium text-center">Encuentro</th>
                                    <th className="p-4 font-medium text-center">Bautismo</th>
                                    <th className="p-4 font-medium">Escuela</th>
                                    <th className="p-4 font-medium text-right">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredMembers.map(member => (
                                    <tr key={member.id} className="border-t hover:bg-muted/50">
                                        <td className="p-4 font-medium">
                                            <div>{member.name}</div>
                                            <div className="text-xs text-muted-foreground">{member.phone}</div>
                                        </td>
                                        <td className="p-4">
                                            <span className={`px-2 py-1 rounded-full text-xs font-semibold ${member.memberType === 'MIEMBRO' ? 'bg-green-100 text-green-700' :
                                                    member.memberType === 'ASISTENTE' ? 'bg-blue-100 text-blue-700' :
                                                        'bg-gray-100 text-gray-700'
                                                }`}>
                                                {member.memberType || 'Visita'}
                                            </span>
                                        </td>
                                        <td className="p-4 text-center">
                                            {member.wentToEncounter ? '✅' : '❌'}
                                        </td>
                                        <td className="p-4 text-center">
                                            {member.isBaptized ? '✅' : '❌'}
                                        </td>
                                        <td className="p-4">{member.leadershipSchoolLevel || 'Ninguno'}</td>
                                        <td className="p-4 text-right">
                                            <Button variant="ghost" size="sm" onClick={() => handleEditClick(member)}>
                                                Editar
                                            </Button>
                                        </td>
                                    </tr>
                                ))}
                                {filteredMembers.length === 0 && (
                                    <tr>
                                        <td colSpan={6} className="p-8 text-center text-muted-foreground">
                                            No se encontraron miembros.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
