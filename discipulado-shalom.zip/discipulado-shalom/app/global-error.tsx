"use client";

import { Button } from "@/components/ui/button";

export default function GlobalError({
    error,
    reset,
}: {
    error: Error & { digest?: string };
    reset: () => void;
}) {
    return (
        <html>
            <body>
                <div className="flex flex-col items-center justify-center min-h-screen bg-red-50 p-4">
                    <h2 className="text-2xl font-bold text-red-900 mb-4">Error Crítico</h2>
                    <p className="text-red-700 mb-8">Ha ocurrido un error inesperado.</p>
                    <Button onClick={() => reset()}>Intentar de nuevo</Button>
                </div>
            </body>
        </html>
    );
}
