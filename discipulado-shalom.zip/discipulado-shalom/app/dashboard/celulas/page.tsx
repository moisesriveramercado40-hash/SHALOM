"use client";

import { useApp } from '@/lib/store';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Users, Plus } from 'lucide-react';

export default function CellsPage() {
    const { user, cells, addCell } = useApp();
    const router = useRouter();
    const [name, setName] = useState('');
    const [leaderEmail, setLeaderEmail] = useState('');
    const [isAdding, setIsAdding] = useState(false);

    useEffect(() => {
        if (user && user.role !== 'DISCIPULADOR') {
            router.push('/dashboard');
        }
    }, [user, router]);

    if (!user || user.role !== 'DISCIPULADOR') return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !leaderEmail) return;

        addCell({
            id: crypto.randomUUID(),
            name,
            leaderId: leaderEmail
        });

        setName('');
        setLeaderEmail('');
        setIsAdding(false);
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-shalom-900">Gestión de Células</h1>
                    <p className="text-muted-foreground">Administre las células y asigne líderes.</p>
                </div>
                <Button onClick={() => setIsAdding(!isAdding)} variant={isAdding ? "secondary" : "default"}>
                    <Plus className={`mr-2 h-4 w-4 transition-transform ${isAdding ? "rotate-45" : ""}`} />
                    {isAdding ? 'Cancelar' : 'Nueva Célula'}
                </Button>
            </div>

            {isAdding && (
                <Card className="border-shalom-200 bg-shalom-50 transition-all duration-300 animate-in fade-in slide-in-from-top-4">
                    <CardHeader>
                        <CardTitle>Agregar Nueva Célula</CardTitle>
                        <CardDescription>Ingrese los datos necesarios para registrar una nueva célula de discipulado.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <label htmlFor="name" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                        Nombre de la Célula
                                    </label>
                                    <Input
                                        id="name"
                                        placeholder="Ej. Jóvenes Victoriosos"
                                        value={name}
                                        onChange={(e) => setName(e.target.value)}
                                        required
                                        className="bg-white"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label htmlFor="leader" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                        Email del Líder
                                    </label>
                                    <Input
                                        id="leader"
                                        type="email"
                                        placeholder="lider@shalom.com"
                                        value={leaderEmail}
                                        onChange={(e) => setLeaderEmail(e.target.value)}
                                        required
                                        className="bg-white"
                                    />
                                    <p className="text-[0.8rem] text-muted-foreground">
                                        Este email se utilizará para vincular al líder con la célula.
                                    </p>
                                </div>
                            </div>
                            <div className="flex justify-end pt-4">
                                <Button type="submit" className="bg-shalom-600 hover:bg-shalom-700">
                                    Guardar Célula
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            )}

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {cells.map((cell) => (
                    <Card key={cell.id} className="hover:shadow-md transition-shadow">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium truncate pr-2" title={cell.name}>{cell.name}</CardTitle>
                            <Users className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{cell.members?.length || 0}</div>
                            <p className="text-xs text-muted-foreground">Miembros activos</p>

                            <div className="mt-4 pt-4 border-t">
                                <div className="flex flex-col gap-1">
                                    <span className="text-xs font-semibold uppercase text-muted-foreground">Líder Asignado</span>
                                    <span className="text-sm truncate" title={cell.leaderId}>{cell.leaderId}</span>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}
