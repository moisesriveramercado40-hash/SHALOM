# Discipulado Shalom App

Sistema de gestión para grupos pequeños (células) con control de asistencia y reportes Excel.

## 📋 Requisitos Previos

Como este proyecto se generó en un entorno sin Node.js instalado, necesitarás instalarlo manualmente para ejecutarlo.

1.  **Descargar Node.js**: Ve a [nodejs.org](https://nodejs.org/) e instala la versión LTS (v18 o superior).
2.  **Verificar instalación**: Abre una terminal (CMD o PowerShell) y escribe:
    ```bash
    node -v
    npm -v
    ```

## 🚀 Instalación y Ejecución Local

1.  **Abrir la carpeta del proyecto**:
    ```bash
    cd discipulado-shalom
    ```

2.  **Instalar dependencias**:
    ```bash
    npm install
    ```

3.  **Ejecutar servidor de desarrollo**:
    ```bash
    npm run dev
    ```

4.  **Abrir en el navegador**:
    Ingresa a `http://localhost:3000`

## 🔑 Credenciales de Acceso (Demo)

El sistema usa autenticación simulada para esta versión gratuita.

- **Rol Discipulador (Admin)**:
  - Email: `discipulador@shalom.com`
  - Acceso total a todas las células y reportes.

- **Rol Líder**:
  - Email: `lider1@shalom.com`
  - Acceso restringido a su célula asignada.

## 🛠️ Despliegue en Vercel (Gratuito)

1.  Sube este proyecto a tu **GitHub**.
2.  Crea una cuenta en [Vercel](https://vercel.com).
3.  Conecta tu cuenta de GitHub.
4.  Importa el repositorio `discipulado-shalom`.
5.  Mantén la configuración por defecto (Framework Preset: Next.js).
6.  Click en **Deploy**.

## 📱 Características

- **Dashboard**: Vista general con métricas y alertas de cumpleaños.
- **Miembros**: Gestión de discípulos.
- **Asistencia**: Control de asistencia diario.
- **Excel**:
    - Descarga de reportes con fórmulas preservadas.
    - Carga de reportes para actualizar datos.
- **Diseño**: Tema verde "Shalom" y responsive.

## 📂 Estructura del Proyecto

- `/app`: Páginas y rutas (Next.js App Router).
- `/components`: Componentes UI reutilizables (Botones, Tarjetas, Sidebar).
- `/lib`: Lógica de negocio (Auth, Excel, Estado Global).
- `/types`: Definiciones de TypeScript.
