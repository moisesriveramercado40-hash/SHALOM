// Base64 string of the Excel template
export const EXCEL_TEMPLATE_BASE64 = "";
