import ExcelJS from "exceljs";
import { Member, Attendance } from "@/types";
import { EXCEL_TEMPLATE_BASE64 } from "./reportTemplate";

// Helper for client-side storage
export async function storeUploadedExcel(
    file: File,
    cellId: string
) {
    const buffer = await file.arrayBuffer();
    const base64 = btoa(
        new Uint8Array(buffer).reduce(
            (data, byte) => data + String.fromCharCode(byte),
            ""
        )
    );

    if (typeof window !== 'undefined') {
        localStorage.setItem(`excel_${cellId}`, base64);
    }
}

export async function generateMonthlyReport(
    month: number,
    year: number,
    members: Member[],
    attendance: Attendance[]
): Promise<ArrayBuffer> {
    const workbook = new ExcelJS.Workbook();

    // Load template if available
    if (EXCEL_TEMPLATE_BASE64) {
        try {
            const buffer = Uint8Array.from(atob(EXCEL_TEMPLATE_BASE64), c => c.charCodeAt(0));
            await workbook.xlsx.load(buffer);
        } catch (e) {
            console.error("Error loading template, creating new workbook", e);
        }
    }

    let worksheet = workbook.getWorksheet(1);
    if (!worksheet) {
        worksheet = workbook.addWorksheet('Reporte Mensual');
    }

    // If using template, assuming headers are already there.
    // We will append rows starting from a specific row (e.g., row 2 or after headers)
    // Adjust logic based on the specific template structure provided by user.
    // For now, we will assume standard structure or create it if template is empty/invalid.

    // Ensure headers exist if creating from scratch or simple template
    if (worksheet.rowCount < 1) {
        worksheet.columns = [
            { header: 'ID', key: 'id', width: 30 },
            { header: 'Nombre', key: 'name', width: 30 },
            { header: 'Teléfono', key: 'phone', width: 20 },
            { header: 'Cumpleaños', key: 'birthday', width: 15 },
            { header: 'Asistencias', key: 'attendanceCount', width: 15 },
            { header: 'Estado', key: 'status', width: 15 },
        ];
    }

    // Find the first empty row to start adding data, or clear existing data if rewriting report
    // For a report download, we typically want to fill it with current data.
    // Simplest approach: Clear existing data rows (keep header) and re-add.

    // Be careful with templates that might have styling or specific layouts.
    // If the user wants "Excel de descargar y subir... sea este modelo", we should try to preserve it.

    // Let's assume row 1 is header.
    const startingRow = 2;

    // Clear old data if any (optional, depends on use case)
    // worksheet.spliceRows(startingRow, worksheet.rowCount - startingRow + 1);

    members.forEach((member, index) => {
        const memberAttendance = attendance.filter(a => {
            const date = new Date(a.date);
            return a.memberId === member.id &&
                date.getMonth() + 1 === month &&
                date.getFullYear() === year &&
                a.status === 'PRESENT';
        });

        const row = worksheet.getRow(startingRow + index);

        // Map data to columns based on the template's expected layout.
        // If template columns match the keys:
        row.getCell(1).value = member.id;
        row.getCell(2).value = member.name;
        row.getCell(3).value = member.phone || '';
        row.getCell(4).value = member.birthday || '';
        row.getCell(5).value = memberAttendance.length;
        row.getCell(6).value = member.active ? 'Activo' : 'Inactivo';

        row.commit();
    });

    const buffer = await workbook.xlsx.writeBuffer();
    return buffer as ArrayBuffer;
}

export async function parseUploadedReport(buffer: ArrayBuffer): Promise<any[]> {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);
    const worksheet = workbook.getWorksheet(1);

    const data: any[] = [];

    if (worksheet) {
        worksheet.eachRow((row, rowNumber) => {
            if (rowNumber > 1) { // Skip header
                // Verify if this row has valid data
                const id = row.getCell(1).value?.toString();
                const name = row.getCell(2).value?.toString();

                if (id && name) {
                    const rowData: any = {
                        id: id,
                        name: name,
                        phone: row.getCell(3).value?.toString(),
                        birthday: row.getCell(4).value?.toString(),
                        attendanceCount: row.getCell(5).value,
                        status: row.getCell(6).value?.toString()
                    };
                    data.push(rowData);
                }
            }
        });
    }

    return data;
}
