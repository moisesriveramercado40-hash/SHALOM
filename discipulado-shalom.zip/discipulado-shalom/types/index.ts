export type Role = 'DISCIPULADOR' | 'LIDER';

export interface User {
    email: string;
    role: Role;
    celulaId?: string; // If LIDER, they are assigned to one cell
    name: string;
}

export interface Member {
    id: string;
    name: string;
    email?: string;
    phone?: string;
    birthday?: string; // ISO Date YYYY-MM-DD
    address?: string;
    joinDate: string;
    active: boolean;
    celulaId: string;
    // Extended fields
    memberType: 'MIEMBRO' | 'ASISTENTE' | 'VISITA';
    wentToEncounter: boolean;
    isBaptized: boolean;
    leadershipSchoolLevel?: 'NINGUNO' | 'NIVEL 1' | 'NIVEL 2' | 'NIVEL 3' | 'GRADUADO';
    guardianAngel?: string;
    isTither: boolean;
    cmeCelStatus?: 'NINGUNO' | 'EN_CURSO' | 'TERMINADO';
}

export interface Attendance {
    id: string;
    memberId: string;
    date: string; // ISO Date YYYY-MM-DD
    status: 'PRESENT' | 'ABSENT' | 'EXCUSED';
    celulaId: string;
}

export interface CellLogistics {
    hostName?: string;
    address?: string;
    district?: string;
    city?: string;
    meetingDay?: string;
    meetingTime?: string;
    startDate?: string;
    multiplicationDate?: string;
}

export interface CellGroup extends CellLogistics {
    id: string;
    name: string;
    leaderId: string;
    members: Member[];
    pastorName?: string;
    discipuladorName?: string;
}

export interface MonthlyReport {
    month: number;
    year: number;
    celulaId: string;
    data: any; // Structure depends on Excel
    submittedat: string;
}
