"use client";

import { useApp } from '@/lib/store';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Users, AlertTriangle, PartyPopper, Calendar } from 'lucide-react';

export default function DashboardPage() {
    const { user, members, cells } = useApp();

    if (!user) return null;

    // FILTER DATA BASED ON ROLE
    const myCells = user.role === 'DISCIPULADOR'
        ? cells
        : cells.filter(c => c.id === user.celulaId);

    const myMembers = user.role === 'DISCIPULADOR'
        ? members
        : members.filter(m => m.celulaId === user.celulaId);

    // METRICS
    const totalMembers = myMembers.length;
    const totalCells = myCells.length;

    // ALERTS: BIRTHDAYS (This Month)
    const currentMonth = new Date().getMonth();
    const birthdays = myMembers.filter(m => {
        if (!m.birthday) return false;
        const date = new Date(m.birthday);
        return date.getMonth() === currentMonth;
    });

    // ALERTS: ABSENT (Mock logic: In a real app, check last attendance date)
    // For demo, we'll just pick active members who haven't "attended" in 2 weeks
    // Since we don't have full attendance history yet, we'll leave this empty or mock it.
    const atRiskMembers = myMembers.filter(m => !m.active);

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-shalom-900">Dashboard</h1>
                    <p className="text-muted-foreground">Bienvenido, {user.name} ({user.role})</p>
                </div>
            </div>

            {/* METRICS GRID */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Células</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{totalCells}</div>
                        <p className="text-xs text-muted-foreground">Activas bajo su supervisión</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Miembros</CardTitle>
                        <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{totalMembers}</div>
                        <p className="text-xs text-muted-foreground">Discípulos registrados</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Cumpleaños Mes</CardTitle>
                        <PartyPopper className="h-4 w-4 text-shalom-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{birthdays.length}</div>
                        <p className="text-xs text-muted-foreground">Celebraciones pendientes</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Inactivos</CardTitle>
                        <AlertTriangle className="h-4 w-4 text-red-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{atRiskMembers.length}</div>
                        <p className="text-xs text-muted-foreground">Requieren atención</p>
                    </CardContent>
                </Card>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
                {/* RECENT ACTIVITY / LIST */}
                <Card className="col-span-4">
                    <CardHeader>
                        <CardTitle>Miembros Recientes</CardTitle>
                        <CardDescription>
                            Últimos miembros añadidos a sus células.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {myMembers.slice(-5).map(member => (
                                <div key={member.id} className="flex items-center justify-between p-2 border rounded-md">
                                    <div>
                                        <p className="font-medium">{member.name}</p>
                                        <p className="text-sm text-muted-foreground">{member.celulaId}</p>
                                    </div>
                                    <div className="text-sm text-shalom-600 font-bold">
                                        {member.active ? 'Activo' : 'Inactivo'}
                                    </div>
                                </div>
                            ))}
                            {myMembers.length === 0 && <p className="text-sm text-muted-foreground">No hay miembros registrados.</p>}
                        </div>
                    </CardContent>
                </Card>

                {/* ALERTS */}
                <Card className="col-span-3">
                    <CardHeader>
                        <CardTitle>Alertas del Mes</CardTitle>
                        <CardDescription>Cumpleaños y seguimiento</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {birthdays.length > 0 ? (
                                birthdays.map(b => (
                                    <div key={b.id} className="flex items-center gap-3">
                                        <div className="p-2 bg-yellow-100 rounded-full text-yellow-600">
                                            <PartyPopper size={16} />
                                        </div>
                                        <div>
                                            <p className="text-sm font-medium">{b.name}</p>
                                            <p className="text-xs text-muted-foreground">Cumpleaños: {b.birthday}</p>
                                        </div>
                                    </div>
                                ))
                            ) : (
                                <p className="text-sm text-muted-foreground">No hay cumpleaños este mes.</p>
                            )}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
