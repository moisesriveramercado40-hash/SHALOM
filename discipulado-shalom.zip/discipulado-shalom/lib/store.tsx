"use client";

import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Member, Attendance, CellGroup } from '@/types';
import { getCells } from './auth';

interface AppState {
    user: User | null;
    cells: CellGroup[];
    members: Member[];
    attendance: Attendance[];
    login: (email: string) => boolean;
    logout: () => void;
    addMember: (member: Member) => void;
    updateMember: (member: Member) => void;
    addAttendance: (attendance: Attendance) => void;
    addCell: (cell: { name: string; leaderId: string; id: string }) => void;
}

const AppContext = createContext<AppState | undefined>(undefined);

// MOCK INITIAL DATA
const INITIAL_MEMBERS: Member[] = [
    { id: '1', name: 'Juan Perez', celulaId: 'cell-1', active: true, joinDate: '2023-01-01', birthday: '1990-05-15', memberType: 'MIEMBRO', wentToEncounter: true, isBaptized: true, leadershipSchoolLevel: 'NIVEL 1', isTither: true, guardianAngel: 'Pedro' },
    { id: '2', name: 'Maria Gomez', celulaId: 'cell-1', active: true, joinDate: '2023-02-01', birthday: '1995-08-20', memberType: 'ASISTENTE', wentToEncounter: false, isBaptized: false, leadershipSchoolLevel: 'NINGUNO', isTither: false, cmeCelStatus: 'EN_CURSO' },
    { id: '3', name: 'Pedro Lopez', celulaId: 'cell-2', active: true, joinDate: '2023-03-01', memberType: 'VISITA', wentToEncounter: false, isBaptized: false, leadershipSchoolLevel: 'NINGUNO', isTither: false },
];

export function AppProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<User | null>(null);
    const [members, setMembers] = useState<Member[]>(INITIAL_MEMBERS);
    const [attendance, setAttendance] = useState<Attendance[]>([]);
    const [baseCells, setBaseCells] = useState<{ id: string; name: string; leaderId: string; address?: string; hostName?: string }[]>([]);

    // Compute cells with members
    const cells = baseCells.map(c => ({
        ...c,
        members: members.filter(m => m.celulaId === c.id)
    }));

    const login = (email: string) => {
        // Dynamic import to avoid SSR issues with static mock
        const { authenticateUser } = require('./auth');
        let foundUser = authenticateUser(email);

        // If not found in static list, check dynamic cells
        if (!foundUser) {
            const cell = baseCells.find(c => c.leaderId.toLowerCase() === email.toLowerCase());
            if (cell) {
                foundUser = {
                    email: cell.leaderId,
                    role: 'LIDER',
                    celulaId: cell.id,
                    name: `Líder: ${cell.name}`,
                };
            }
        }

        if (foundUser) {
            setUser(foundUser);
            localStorage.setItem('discipulado_user', JSON.stringify(foundUser));
            return true;
        }
        return false;
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('discipulado_user');
    };

    const addMember = (member: Member) => {
        setMembers([...members, member]);
    };

    const updateMember = (updated: Member) => {
        setMembers(members.map(m => m.id === updated.id ? updated : m));
    };

    const addAttendance = (record: Attendance) => {
        setAttendance([...attendance, record]);
    };

    // Updated to accept any properties compatible with CellGroup
    const addCell = (newCell: any) => {
        // Ensure defaults specific to Cusco
        const cellWithDefaults = {
            city: 'Cusco',
            district: 'Cusco',
            ...newCell
        };
        const updated = [...baseCells, cellWithDefaults];
        setBaseCells(updated);
        localStorage.setItem('discipulado_cells', JSON.stringify(updated));
    };

    // Hydrate user and cells on mount
    useEffect(() => {
        const storedUser = localStorage.getItem('discipulado_user');
        if (storedUser) {
            setUser(JSON.parse(storedUser));
        }

        const storedCells = localStorage.getItem('discipulado_cells');
        if (storedCells) {
            setBaseCells(JSON.parse(storedCells));
        } else {
            // Lazy load initial cells only if nothing stored
            const { getCells } = require('./auth');
            // Initialize with defaults
            const initialCells = getCells().map((c: any) => ({
                ...c,
                district: 'Cusco',
                city: 'Cusco',
                meetingDay: 'Sábado',
                meetingTime: '17:00'
            }));
            setBaseCells(initialCells);
        }
    }, []);

    return (
        <AppContext.Provider value={{ user, cells, members, attendance, login, logout, addMember, updateMember, addAttendance, addCell }}>
            {children}
        </AppContext.Provider>
    );
}

export function useApp() {
    const context = useContext(AppContext);
    if (context === undefined) {
        throw new Error('useApp must be used within an AppProvider');
    }
    return context;
}
