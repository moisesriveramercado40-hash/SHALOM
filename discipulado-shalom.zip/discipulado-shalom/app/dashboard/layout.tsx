"use client";

import { Sidebar } from '@/components/Sidebar';
import { useApp } from '@/lib/store';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function DashboardLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const { user } = useApp();
    const router = useRouter();

    useEffect(() => {
        if (!user) {
            // Double check local storage if reload
            const stored = localStorage.getItem('discipulado_user');
            if (!stored) {
                router.push('/');
            }
        }
    }, [user, router]);

    if (!user) return null; // Avoid flash of content

    return (
        <div className="flex min-h-screen bg-gray-50">
            <Sidebar />
            <div className="flex-1 flex flex-col h-screen overflow-hidden">
                <main className="flex-1 overflow-y-auto p-4 md:p-8">
                    {children}
                </main>
            </div>
        </div>
    );
}
