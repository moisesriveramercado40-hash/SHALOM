"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useApp } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { ShieldCheck } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();
  const { login } = useApp();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(email)) {
      router.push('/dashboard');
    } else {
      setError('Email no autorizado. Intente con prueba@shalom.com o lider1@shalom.com');
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-shalom-50 p-4">
      <Card className="w-full max-w-md border-shalom-200 shadow-xl">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-shalom-100 rounded-full">
              <ShieldCheck className="w-10 h-10 text-shalom-600" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-shalom-900">Discipulado Shalom</CardTitle>
          <CardDescription>
            Ingrese su correo electrónico para acceder
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Input
                type="email"
                placeholder="nombre@ejemplo.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="border-shalom-300 focus-visible:ring-shalom-500"
              />
            </div>
            {error && <p className="text-sm text-red-500 font-medium">{error}</p>}
            <Button type="submit" className="w-full bg-shalom-600 hover:bg-shalom-700 text-white font-bold">
              Ingresar
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2 text-center text-xs text-muted-foreground bg-shalom-50/50 p-4 rounded-b-lg">
          <p>Solo personal autorizado.</p>
          <p className="opacity-70">Demo: discipulador@shalom.com / roy@shalom.com</p>
        </CardFooter>
      </Card>
    </div>
  );
}
