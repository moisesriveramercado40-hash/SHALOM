"use client";

import { useState } from 'react';
import { useApp } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Check, X, Clock } from 'lucide-react';

export default function AttendancePage() {
    const { user, members, addAttendance } = useApp();
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [statusMap, setStatusMap] = useState<Record<string, 'PRESENT' | 'ABSENT' | 'EXCUSED'>>({});
    const [submitted, setSubmitted] = useState(false);

    if (!user) return null;

    const myMembers = user.role === 'DISCIPULADOR'
        ? [] // Discipulador mostly views reports, but for simplify, let's say they don't take attendance directly here
        : members.filter(m => m.celulaId === user.celulaId && m.active);

    const handleStatusChange = (memberId: string, status: 'PRESENT' | 'ABSENT' | 'EXCUSED') => {
        setStatusMap(prev => ({ ...prev, [memberId]: status }));
    };

    const handleSubmit = () => {
        if (!user.celulaId) return;

        // Save all
        Object.entries(statusMap).forEach(([memberId, status]) => {
            addAttendance({
                id: Math.random().toString(36),
                memberId,
                date,
                status,
                celulaId: user.celulaId!
            });
        });
        setSubmitted(true);
    };

    if (user.role === 'DISCIPULADOR') {
        return (
            <div className="p-8 text-center text-muted-foreground">
                <h1 className="text-2xl font-bold text-shalom-900 mb-2">Asistencia</h1>
                <p>El Discipulador revisa los reportes mensuales. La toma de asistencia es responsabilidad de los líderes.</p>
            </div>
        );
    }

    if (submitted) {
        return (
            <div className="flex flex-col items-center justify-center h-[50vh] text-center space-y-4">
                <div className="p-4 bg-green-100 rounded-full text-green-600">
                    <Check size={48} />
                </div>
                <h2 className="text-2xl font-bold">¡Asistencia Guardada!</h2>
                <p className="text-muted-foreground">Los datos han sido registrados correctamente para el día {date}.</p>
                <Button onClick={() => { setSubmitted(false); setStatusMap({}); }} variant="outline">
                    Tomar otra asistencia
                </Button>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-shalom-900">Control de Asistencia</h1>
                    <p className="text-muted-foreground">Marque la asistencia de hoy</p>
                </div>
                <input
                    type="date"
                    className="border p-2 rounded-md"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                />
            </div>

            <Card>
                <CardContent className="p-0">
                    <div className="divide-y">
                        {myMembers.map(member => (
                            <div key={member.id} className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors">
                                <div className="font-medium">{member.name}</div>
                                <div className="flex gap-2">
                                    <Button
                                        size="sm"
                                        variant={statusMap[member.id] === 'PRESENT' ? 'default' : 'outline'}
                                        className={statusMap[member.id] === 'PRESENT' ? "bg-shalom-600" : ""}
                                        onClick={() => handleStatusChange(member.id, 'PRESENT')}
                                    >
                                        <Check size={16} className="mr-1" /> Presente
                                    </Button>

                                    <Button
                                        size="sm"
                                        variant={statusMap[member.id] === 'ABSENT' ? 'destructive' : 'outline'}
                                        onClick={() => handleStatusChange(member.id, 'ABSENT')}
                                    >
                                        <X size={16} className="mr-1" /> Falta
                                    </Button>

                                    <Button
                                        size="sm"
                                        variant={statusMap[member.id] === 'EXCUSED' ? 'secondary' : 'outline'}
                                        className={statusMap[member.id] === 'EXCUSED' ? "bg-yellow-100 text-yellow-700 hover:bg-yellow-200" : ""}
                                        onClick={() => handleStatusChange(member.id, 'EXCUSED')}
                                    >
                                        <Clock size={16} className="mr-1" /> Permiso
                                    </Button>
                                </div>
                            </div>
                        ))}
                        {myMembers.length === 0 && (
                            <div className="p-8 text-center text-muted-foreground">No hay miembros activos en esta célula.</div>
                        )}
                    </div>
                </CardContent>
            </Card>

            <div className="flex justify-end">
                <Button size="lg" className="bg-shalom-700 hover:bg-shalom-800" onClick={handleSubmit} disabled={Object.keys(statusMap).length === 0}>
                    Guardar Asistencia
                </Button>
            </div>
        </div>
    );
}
